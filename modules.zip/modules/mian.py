from input_module import get_input
from processing_module import calculate
from output_module import display_and_log_results

def main():
    try:
        num1, num2, operator = get_input()
        operation, result = calculate(num1, num2, operator)
        display_and_log_results(num1, num2, operator, operation, result)
    except ValueError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
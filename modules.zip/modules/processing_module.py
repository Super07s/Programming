def calculate(num1, num2, operator):
    if operator == "+":
        result = num1 + num2
        operation = "sum"
    elif operator == "-":
        result = num1 - num2
        operation = "difference"
    elif operator == "*":
        result = num1 * num2
        operation = "product"
    elif operator == "/":
        if num2 == 0:
            raise ValueError("Division by zero is not allowed.")
        result = num1 / num2
        operation = "quotient"
    else:
        raise ValueError(f"Invalid operator: {operator}")
    return operation, result
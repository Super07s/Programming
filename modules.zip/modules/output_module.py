def display_and_log_results(num1, num2, operator, operation, result, filename="calculations.txt"):
    output = f"The {operation} of {num1} and {num2} is {result}"
    print(output)
    with open(filename, "a") as file:
        file.write(output + "\n")
